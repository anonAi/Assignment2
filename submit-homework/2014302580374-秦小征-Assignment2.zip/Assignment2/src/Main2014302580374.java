import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

public class Main2014302580374 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String url = "http://gr.xjtu.edu.cn/web/zdjiang;jsessionid=CE5732666D69EC9A7E47A1FA9552367B";
		 String fName = "./test.html";
		 String name = "";
		 String jianjie = "";
		 String yanjiu = "";
		 String mail = "";
		 String tel = "";
		 HttpRequest response = HttpRequest.get(url);
		 response.receive(new File(fName));
		 String inFile = file2String(new File("./test.html"));
		 Document doc = Jsoup.parse(inFile);
		 Elements els = doc.getElementsByClass("logo");
		 for(Element tem : els){
			 Elements tema = tem.getElementsByClass("current-community");
			 for(Element t: tema){
				 name = t.html();
			 }
		 }
		Element el = doc.getElementById("column-1");
		els = el.getElementsByTag("span");
		int i = 0;
		for(Element tem: els){
			if(i == 4){
				break;
			}
			if(i == 0){
				i++;
				continue;
			}
			jianjie += tem.html();
			i++;
		}
		jianjie = jianjie.substring(18, 69);
		els = doc.getElementsByTag("font");
		i = 0;
		for(Element t: els){
			if(i == 0){
				yanjiu = t.html();
			}
			i++;
		}
		Pattern pa = Pattern.compile("0\\d\\d-\\d\\d\\d\\d\\d\\d\\d\\d");
		Matcher mr = pa.matcher(inFile);
		if(mr.find()){
			tel = mr.group(0);
		}
		//pa = Pattern.compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
		pa = Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9.]*");
		
		mr = pa.matcher(inFile);
		if(mr.find()){
			mail = mr.group(0);
		}
		name = name.substring(0, 1) + name.substring(2,4);
		System.out.println("name" + name + "jianjie" + jianjie + "yanjiu" + yanjiu + "mail" + mail + "tel" + tel);
		String output = "����: " + name + "\r\n" + "���: " + jianjie + "\r\n" + "�о�����: "+ yanjiu + "\r\n"  + "mail: " + mail + "\r\n" + "tel: " + tel + "\r\n";
		output += "get from website: http://gr.xjtu.edu.cn";
		ByteArrayInputStream outStream = new ByteArrayInputStream(output.getBytes());
		File outFile = new File("./output.txt");
		inputstreamtofile(outStream, outFile);
		 System.out.println("end");
	}
	// tool function 

	public static void inputstreamtofile(InputStream ins,File file) throws IOException{
		   OutputStream os = new FileOutputStream(file);
		   int bytesRead = 0;
		   byte[] buffer = new byte[8192];
		   while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
		      os.write(buffer, 0, bytesRead);
		   }
		   os.close();
		   ins.close();
	}
	public static String file2String(File file) throws IOException{
		InputStream is = new FileInputStream(file);
		BufferedReader in = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		StringBuffer buffer = new StringBuffer();
		String line = "";
		while((line = in.readLine()) != null){
			buffer.append(line);
		}
		in.close();
		return buffer.toString();
	}
}
